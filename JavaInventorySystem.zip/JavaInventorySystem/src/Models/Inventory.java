package Models;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * @author Andrew Walsh
 */
public class Inventory {
    private ObservableList<Part> allParts = FXCollections.observableArrayList();
    private ObservableList<Product> allProducts = FXCollections.observableArrayList();

    /**
     * @param newPart part to add
     */
    public void addPart(Part newPart) {
        this.allParts.add(newPart);
    }

    /**
     * @param newProduct product to add
     */
    public void addProduct(Product newProduct) {
        this.allProducts.add(newProduct);
    }

    /**
     * @param partId id of part to find
     * @return part that is found
     */
    public Part lookupPart(int partId) {
        for (Part part : this.allParts) {
            if (part.getId() == partId) {
                return part;
            }
        }
        return null;
    }

    /**
     * @param productId id of product to find
     * @return product that is found
     */
    public Product lookupProduct(int productId) {
        for (Product product : this.allProducts) {
            if (product.getId() == productId) {
                return product;
            }
        }
        return null;
    }

    /**
     * @param partName name of part(s) to find
     * @return part(s) that are found
     */
    public ObservableList<Part> lookupPart(String partName) {
        ObservableList<Part> results = FXCollections.observableArrayList();
        for (Part part : this.allParts) {
            if (part.getName().equals(partName)) {
                results.add(part);
            }
        }
        return results;
    }

    /**
     * @param productName name of product(s) to find
     * @return product(s) that are found
     */
    public ObservableList<Product> lookupProduct(String productName) {
        ObservableList<Product> results = FXCollections.observableArrayList();
        for (Product product : this.allProducts) {
            if (product.getName().equals(productName)) {
                results.add(product);
            }
        }
        return results;
    }

    /**
     * @param index index to be updated
     * @param selectedPart part to set in that index
     */
    public void updatePart(int index, Part selectedPart) {
        this.allParts.set(index, selectedPart);
    }

    /**
     * @param index index to be updated
     * @param newProduct product to be set in that index
     */
    public void updateProduct(int index, Product newProduct) {
        this.allProducts.set(index, newProduct);
    }

    /**
     * @param selectedPart part to delete
     * @return boolean status of delete operation
     */
    public boolean deletePart(Part selectedPart) {
        return this.allParts.remove(selectedPart);
    }

    /**
     * @param selectedProduct product to delete
     * @return boolean status of delete operation
     */
    public boolean deleteProduct(Product selectedProduct) {
        return this.allProducts.remove(selectedProduct);
    }

    /**
     * @return all parts in inventory
     */
    public ObservableList<Part> getAllParts() {
        return this.allParts;
    }

    /**
     * @return all products in inventory
     */
    public ObservableList<Product> getAllProducts() {
        return this.allProducts;
    }
}
