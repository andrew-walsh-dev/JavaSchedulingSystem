package Controllers;

import Models.*;
import com.sun.javafx.geom.AreaOp;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * @author Andrew Walsh
 */
public class MainFormController {
    Inventory inventory;

    //main form
    @FXML
    TableView<Part> mainPartsTable;
    @FXML
    TableView<Product> mainProductsTable;
    @FXML
    TableColumn<Part, Integer> mainFormPartIdColumn, mainFormPartInvLevelColumn;
    @FXML
    TableColumn<Product, Integer> mainFormProductIdColumn, mainFormProductInvLevelColumn;
    @FXML
    TableColumn<Part, String> mainFormPartNameColumn;
    @FXML
    TableColumn<Product, String> mainFormProductNameColumn;
    @FXML
    TableColumn<Part, Double> mainFormPartPricePerUnitColumn;
    @FXML
    TableColumn<Product, Double> mainFormProductPricePerUnitColumn;
    @FXML
    TextField mainSearchPart, mainSearchProduct;
    @FXML
    Button mainAddPartButton, mainAddProductButton, mainModifyProductButton, mainModifyPartButton, mainDeletePartButton, mainDeleteProductButton, mainExitButton;

    /**
     * @param inventory the inventory to set
     */
    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    /**
     * function to initialize the main form
     */
    @FXML
    public void initialize() {
        if (Objects.isNull(inventory)) {
            this.inventory = new Inventory();
            inventory.addPart(new InHouse(1, "in house item", 2.00, 5, 3, 9, 5));
            inventory.addPart(new Outsourced(2, "outsourced item", 5.00, 9, 7, 10, "GoodWorks"));
            inventory.addProduct(new Product(1, "Awesome Product", 20.99, 12, 10, 19));
        }
        populateMainForm();
    }

    /**
     * function to run when the exit button is interacted with
     */
    public void onMainExitButtonAction() {
       Stage stage = (Stage) mainExitButton.getScene().getWindow();
       stage.close();
    }

    /**
     * function to run when the add part button is interacted with
     * @throws IOException
     */
    @FXML
    public void onMainAddPartButtonAction() throws IOException {
        Stage stage = (Stage) mainAddPartButton.getScene().getWindow();
        FXMLLoader loader= new FXMLLoader(getClass().getResource(
               "../FXML/addPart.fxml"));
        Parent parent = loader.load();
        Scene scene = new Scene(parent);
        stage.setScene(scene);
        stage.show();
        AddPartController controller = (AddPartController) loader.getController();
        controller.setInventory(this.inventory);
    }

    /**
     * function to run when the add product button is interacted with
     * @throws IOException
     */
    @FXML
    public void onMainAddProductButtonAction() throws IOException {
        Stage stage = (Stage) mainAddPartButton.getScene().getWindow();
        FXMLLoader loader= new FXMLLoader(getClass().getResource(
               "../FXML/addProduct.fxml"));
        Parent parent = loader.load();
        Scene scene = new Scene(parent);
        stage.setScene(scene);
        stage.show();
        AddProductController controller = (AddProductController) loader.getController();
        controller.inventory = this.inventory;
        controller.populateAddProductForm();
    }

    /**
     * function to run when the part search bar is interacted with
     */
    public void onPartSearchBarChange() {
        if (mainSearchPart.getText().equals("")) {
            mainPartsTable.setItems(inventory.getAllParts());
        }
        else {
            String query = mainSearchPart.getText();
            ObservableList<Part> parts = FXCollections.observableArrayList();
            for (Part part : inventory.getAllParts()) {
                if ((part.getId() + "").equals(query) || part.getName().toLowerCase().contains(query.toLowerCase())) {
                    parts.add(part);
                }
            }
            if (parts.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Alert");
                alert.setHeaderText("No Parts Found");
                alert.setContentText("None of the parts in the inventory match that search query.");

                alert.showAndWait();
            }
            mainPartsTable.setItems(parts);
        }
    }

    /**
     * function to run when the product search bar is interacted with
     */
    public void onProductSearchBarChange() {
        if (mainSearchProduct.getText().equals("")) {
            mainProductsTable.setItems(inventory.getAllProducts());
        }
        else {
            String query = mainSearchProduct.getText();
            ObservableList<Product> products = FXCollections.observableArrayList();
            for (Product product : inventory.getAllProducts()) {
                if ((product.getId() + "").equals(query) || product.getName().toLowerCase().contains(query.toLowerCase())) {
                    products.add(product);
                }
            }
            if (products.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Alert");
                alert.setHeaderText("No Products Found");
                alert.setContentText("None of the products in the inventory match that search query.");

                alert.showAndWait();
            }
            mainProductsTable.setItems(products);
        }
    }

    /**
     * function to run when the delete part button is interacted with
     */
    public void onPartDeleteButtonAction() {
        Part part = mainPartsTable.getSelectionModel().getSelectedItem();
        if (part != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Alert");
            alert.setHeaderText("Delete Part");
            alert.setContentText("Are you sure you want to delete this part?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK){
                inventory.deletePart(part);
                populateMainForm();
            } else {

            }
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("No Part Selected");
            alert.setContentText("You must select a part before pressing delete part.");

            alert.showAndWait();
        }
    }

    /**
     * function to run when the delete product button is interacted with
     */
    public void onProductDeleteButtonAction() {
        Product product = mainProductsTable.getSelectionModel().getSelectedItem();
        if (product != null) {
            if (product.getAssociatedParts() == null || product.getAssociatedParts().isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Alert");
                alert.setHeaderText("Delete Product");
                alert.setContentText("Are you sure you want to delete this product?");

                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK){
                    inventory.deleteProduct(product);
                    populateMainForm();
                } else {

                }
            }
            else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Associated Parts");
                alert.setContentText("You cannot delete a product that has parts associated with it.");

                alert.showAndWait();
            }
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);

            alert.setTitle("Error");
            alert.setHeaderText("No product Selected");
            alert.setContentText("You must select a product before pressing delete part.");

            alert.showAndWait();
        }
    }

    /**
     * function to run when the modify part button is interacted with
     * @throws IOException
     */
    public void onPartModifyButtonAction() throws IOException {
        if (mainPartsTable.getSelectionModel().getSelectedItem() != null) {
            Stage stage = (Stage) mainModifyPartButton.getScene().getWindow();
        FXMLLoader loader= new FXMLLoader(getClass().getResource(
               "../FXML/modifyPart.fxml"));
        Parent parent = loader.load();
        Scene scene = new Scene(parent);
        stage.setScene(scene);
        stage.show();
        ModifyPartController controller = (ModifyPartController) loader.getController();
        controller.inventory = this.inventory;
        controller.partToModify = mainPartsTable.getSelectionModel().getSelectedItem();
        controller.populateModifyPartForm();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("No Part Selected");
            alert.setContentText("You must select a part before pressing modify part.");

            alert.showAndWait();
        }
    }

    /**
     * function to run when the modify product button is interacted with
     * @throws IOException
     */
    public void onProductModifyButtonAction() throws IOException {
        if (mainProductsTable.getSelectionModel().getSelectedItem() != null) {
            Stage stage = (Stage) mainModifyPartButton.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource(
                    "../FXML/modifyProduct.fxml"));
            Parent parent = loader.load();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.show();
            ModifyProductController controller = (ModifyProductController) loader.getController();
            controller.inventory = this.inventory;
            controller.productToModify = mainProductsTable.getSelectionModel().getSelectedItem();
            controller.populateModifyProductForm();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("No Product Selected");
            alert.setContentText("You must select a product before pressing modify part.");

            alert.showAndWait();
        }

    }

    /**
     * function to populate the main form with the correct data
     */
    public void populateMainForm() {
        mainFormPartIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        mainFormPartNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        mainFormPartInvLevelColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        mainFormPartPricePerUnitColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        mainFormProductIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        mainFormProductNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        mainFormProductInvLevelColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        mainFormProductPricePerUnitColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        ObservableList<Part> parts = inventory.getAllParts();
        ObservableList<Product> products = inventory.getAllProducts();
        mainPartsTable.setItems(parts);
        mainProductsTable.setItems(products);
    }
}
