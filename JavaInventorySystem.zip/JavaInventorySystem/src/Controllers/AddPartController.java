package Controllers;

import Models.InHouse;
import Models.Inventory;
import Models.Outsourced;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * @author Andrew Walsh
 * LOGICAL ERROR: I was trying to set this controller's inventory attribute using an initialize method,
 *                  this was not working because the initialize method was running before I could pass the inventory over
 *                  from the previous controller. I was able to resolve this by using the setInventory method below to set
 *                  the inventory after loading up addPart.fxml
 */
public class AddPartController {
    Inventory inventory;
    @FXML
    RadioButton addPartInHouseRadio, addPartOutsourcedRadio;
    @FXML
    TextField addPartPriceTextField, addPartIdTextField, addPartNameTextField, addPartMinTextField, addPartMaxTextField, addPartInvTextField, addPartMachineIdOrCompanyNameTextField;
    @FXML
    Button addPartSaveButton, addPartCancelButton;
    @FXML
    Label addPartMachineIdOrCompanyNameLabel;

    /**
     * @param inventory inventory to set
     */
    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    /**
     * function to run when a radio button is interacted with
     */
    public void onRadioButtonAction() {
        if (addPartInHouseRadio.isSelected()) {
            addPartMachineIdOrCompanyNameLabel.setText("Machine ID");
        } else {
            addPartMachineIdOrCompanyNameLabel.setText("Company Name");
        }
    }

    /**
     * function to run when the cancel button is interacted with
     * @throws IOException
     */
    public void onCancelButtonAction() throws IOException {
        Stage stage = (Stage) addPartCancelButton.getScene().getWindow();
        Parent parent = FXMLLoader.load(getClass().getResource("../FXML/main.fxml"));
        Scene scene = new Scene(parent);
        MainFormController controller = new MainFormController();
        controller.inventory = this.inventory;
        stage.setScene(scene);
        stage.show();
    }

    /**
     * function to run when the save button is interacted with
     * @throws IOException
     */
    public void onSaveButtonAction() throws IOException {
        try {
            String name = addPartNameTextField.getText();
            int inv = Integer.parseInt(addPartInvTextField.getText());
            int min = Integer.parseInt(addPartMinTextField.getText());
            int max = Integer.parseInt(addPartMaxTextField.getText());
            if (min <= inv && inv <= max && min < max) {
                double price = Double.parseDouble(addPartPriceTextField.getText());
                int id;
                if (!inventory.getAllParts().isEmpty()) {
                    id = inventory.getAllParts().get(inventory.getAllParts().size() - 1).getId() + 1;
                } else {
                    id = 1;
                }
                if (addPartInHouseRadio.isSelected()) {
                    int machineId = Integer.parseInt(addPartMachineIdOrCompanyNameTextField.getText());
                    inventory.addPart(new InHouse(id, name, price, inv, min, max, machineId));
                } else {
                    String companyName = addPartMachineIdOrCompanyNameTextField.getText();
                    inventory.addPart(new Outsourced(id, name, price, inv, min, max, companyName));
                }
                Stage stage = (Stage) addPartSaveButton.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader(getClass().getResource(
                        "../FXML/main.fxml"));
                Parent parent = loader.load();
                Scene scene = new Scene(parent);
                stage.setScene(scene);
                stage.show();
                MainFormController controller = (MainFormController) loader.getController();
                controller.setInventory(this.inventory);
                controller.populateMainForm();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Input Error");
                alert.setContentText("Min must be less than max. Inv must be between min and max.");

                alert.showAndWait();
            }
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Input Error");
            alert.setContentText(e.toString());

            alert.showAndWait();
        }
    }
}
