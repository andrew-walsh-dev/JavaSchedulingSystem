package Controllers;

import Models.InHouse;
import Models.Inventory;
import Models.Outsourced;
import Models.Part;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * @author Andrew Walsh
 */
public class ModifyPartController {
    Inventory inventory;
    Part partToModify;
    ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    ObservableList<Part> allParts;

    @FXML
    RadioButton addPartInHouseRadio, addPartOutsourcedRadio;
    @FXML
    TextField addPartPriceTextField, addPartIdTextField, addPartNameTextField, addPartMinTextField, addPartMaxTextField, addPartInvTextField, addPartMachineIdOrCompanyNameTextField;
    @FXML
    Button addPartSaveButton, addPartCancelButton;
    @FXML
    Label addPartMachineIdOrCompanyNameLabel;

    /**
     * function to populate the modify part form with the correct data
     */
    public void populateModifyPartForm() {
        addPartIdTextField.setPromptText(partToModify.getId() + "");
        addPartNameTextField.setText(partToModify.getName());
        addPartInvTextField.setText(partToModify.getStock() + "");
        addPartMaxTextField.setText(partToModify.getMax() + "");
        addPartMinTextField.setText(partToModify.getMin() + "");
        addPartPriceTextField.setText(partToModify.getPrice() + "");
        if (partToModify instanceof InHouse) {
            addPartMachineIdOrCompanyNameLabel.setText("Machine ID");
            addPartMachineIdOrCompanyNameTextField.setText(((InHouse) partToModify).getMachineId() + "");
            addPartInHouseRadio.setSelected(true);
            addPartOutsourcedRadio.setSelected(false);
        }
        else {
            addPartMachineIdOrCompanyNameLabel.setText("Company Name");
            addPartMachineIdOrCompanyNameTextField.setText(((Outsourced) partToModify).getCompanyName() + "");
            addPartInHouseRadio.setSelected(false);
            addPartOutsourcedRadio.setSelected(true);
        }
    }

    /**
     * function to run when a radio button is interacted with
     */
    public void onRadioButtonAction() {
        if (addPartInHouseRadio.isSelected()) {
            addPartMachineIdOrCompanyNameLabel.setText("Machine ID");
        }
        else {
            addPartMachineIdOrCompanyNameLabel.setText("Company Name");
        }
        addPartMachineIdOrCompanyNameTextField.setText("");
    }

    /**
     * function to run when the cancel button is interacted with
     * @throws IOException
     */
    public void onCancelButtonAction() throws IOException {
        Stage stage = (Stage) addPartCancelButton.getScene().getWindow();
        Parent parent = FXMLLoader.load(getClass().getResource("../FXML/main.fxml"));
        Scene scene = new Scene(parent);
        MainFormController controller = new MainFormController();
        controller.inventory = this.inventory;
        stage.setScene(scene);
        stage.show();
    }

    /**
     * function to run when the save button is interacted with
     * @throws IOException
     */
    public void onSaveButtonAction() throws IOException {
        try {
            String name = addPartNameTextField.getText();
            int inv = Integer.parseInt(addPartInvTextField.getText());
            int min = Integer.parseInt(addPartMinTextField.getText());
            int max = Integer.parseInt(addPartMaxTextField.getText());
            if (min <= inv && inv <= max && min < max) {
                double price = Double.parseDouble(addPartPriceTextField.getText());
                int id = inventory.getAllParts().get(inventory.getAllParts().size() - 1).getId() + 1;
                if (addPartInHouseRadio.isSelected()) {
                    int machineId = Integer.parseInt(addPartMachineIdOrCompanyNameTextField.getText());
                    for (int i = 0; i < inventory.getAllParts().size(); i++) {
                        if (inventory.getAllParts().get(i).getId() == partToModify.getId()) {
                            inventory.updatePart(i, new InHouse(id, name, price, inv, min, max, machineId));
                            break;
                        }
                    }
                } else {
                    String companyName = addPartMachineIdOrCompanyNameTextField.getText();
                    for (int i = 0; i < inventory.getAllParts().size(); i++) {
                        if (inventory.getAllParts().get(i).getId() == partToModify.getId()) {
                            inventory.updatePart(i, new Outsourced(id, name, price, inv, min, max, companyName));
                            break;
                        }
                    }
                }
                Stage stage = (Stage) addPartSaveButton.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader(getClass().getResource(
                        "../FXML/main.fxml"));
                Parent parent = loader.load();
                Scene scene = new Scene(parent);
                stage.setScene(scene);
                stage.show();
                MainFormController controller = (MainFormController) loader.getController();
                controller.setInventory(this.inventory);
                controller.populateMainForm();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Input Error");
                alert.setContentText("Min must be less than max. Inv must be between min and max.");

                alert.showAndWait();
            }
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Input Error");
            alert.setContentText(e.toString());

            alert.showAndWait();
        }
    }

}
