package Controllers;

import Models.InHouse;
import Models.Inventory;
import Models.Part;
import Models.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;

/**
 * @author Andrew Walsh
 */
public class ModifyProductController {
    Inventory inventory;
    Product productToModify;
    ObservableList<Part> associatedParts;
    ObservableList<Part> allParts;

    @FXML
    TextField idTextField, nameTextField, invTextField, priceTextField, maxTextField, minTextField, searchPart;
    @FXML
    TableView<Part> allPartsTable, associatedPartsTable;
    @FXML
    Button addPart, removePart, save, cancel;
    @FXML
    TableColumn allPartsPartIdColumn, allPartsPartNameColumn, allPartsInvLevelColumn, allPartsPricePerUnitColumn, associatedPartsPartIdColumn, associatedPartsPartNameColumn, associatedPartsInvLevelColumn, associatedPartsPricePerUnitColumn;

    /**
     * function to populate the modify product form with the correct data
     */
    public void populateModifyProductForm() {
        if (allParts == null) {
            idTextField.setText(productToModify.getId() + "");
            nameTextField.setText(productToModify.getName());
            priceTextField.setText(productToModify.getPrice() + "");
            minTextField.setText(productToModify.getMin() + "");
            maxTextField.setText(productToModify.getMax() + "");
            invTextField.setText(productToModify.getStock() + "");
            allParts = inventory.getAllParts();
            associatedParts = productToModify.getAssociatedParts();
            if (associatedParts != null) {
//                for (Part part : allParts) {
//                    if (associatedParts.contains(part)) {
//                        allParts.remove(part);
//                    }
//                }
            }
            else {
                associatedParts = FXCollections.observableArrayList();
            }

        }
        allPartsPartIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        allPartsPartNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        allPartsInvLevelColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        allPartsPricePerUnitColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        associatedPartsPartIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        associatedPartsPartNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        associatedPartsInvLevelColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        associatedPartsPricePerUnitColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        allPartsTable.setItems(allParts);
        associatedPartsTable.setItems(associatedParts);
    }

    /**
     * function to run when the part search bar is interacted with
     */
    public void onPartSearchBarChange() {
        if (searchPart.getText().equals("")) {
            allPartsTable.setItems(inventory.getAllParts());
        }
        else {
            String query = searchPart.getText();
            ObservableList<Part> parts = FXCollections.observableArrayList();
            for (Part part : allParts) {
                if ((part.getId() + "").equals(query) || part.getName().toLowerCase().contains(query.toLowerCase())) {
                    parts.add(part);
                }
            }
            allPartsTable.setItems(parts);
        }
    }

    /**
     * function to run when the add part button is interacted with
     */
    public void onAddPartButtonAction() {
            Part part = allPartsTable.getSelectionModel().getSelectedItem();
            if (part != null) {
                if (!associatedParts.contains(part)) {
                    associatedParts.add(part);
                }
//                allParts.remove(part);
                populateModifyProductForm();
            }
    }

    /**
     * function to run when the remove part button is interacted with
     */
    public void onRemovePartButtonAction() {
        Part part = associatedPartsTable.getSelectionModel().getSelectedItem();
        if (part != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Alert");
            alert.setHeaderText("Remove Part");
            alert.setContentText("Are you sure you want to remove this associated part?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK){
//                allParts.add(part);
                associatedParts.remove(part);
                populateModifyProductForm();
            } else {

            }
        }
    }

    /**
     * function to run when the save button is interacted with
     * @throws IOException
     */
    public void onSaveButtonAction() throws IOException {
        try {
            int id = productToModify.getId();
            String name = nameTextField.getText();
            int inv = Integer.parseInt(invTextField.getText());
            int max = Integer.parseInt(maxTextField.getText());
            int min = Integer.parseInt(minTextField.getText());
            if (min <= inv && inv <= max && min < max) {
                double price = Double.parseDouble(priceTextField.getText());
                for (int i = 0; i < inventory.getAllParts().size(); i++) {
                    if (inventory.getAllProducts().get(i).getId() == productToModify.getId()) {
                        ObservableList<Part> associatedParts = associatedPartsTable.getItems();
                        System.out.println(associatedParts);
                        Product newProduct = new Product(id, name, price, inv, min, max);
                        newProduct.setAssociatedParts(associatedParts);
                        inventory.updateProduct(i, newProduct);
                        break;
                    }
                }
                Stage stage = (Stage) save.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader(getClass().getResource(
                        "../FXML/main.fxml"));
                Parent parent = loader.load();
                Scene scene = new Scene(parent);
                stage.setScene(scene);
                stage.show();
                MainFormController controller = (MainFormController) loader.getController();
                controller.setInventory(this.inventory);
                controller.populateMainForm();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Input Error");
                alert.setContentText("Min must be less than max. Inv must be between min and max.");

                alert.showAndWait();
            }
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Input Error");
            alert.setContentText(e.toString());

            alert.showAndWait();
        }
    }

    /**
     * function to run when the cancel button is interacted with
     * @throws IOException
     */
    public void onCancelButtonAction() throws IOException {
        Stage stage = (Stage) cancel.getScene().getWindow();
        Parent parent = FXMLLoader.load(getClass().getResource("../FXML/main.fxml"));
        Scene scene = new Scene(parent);
        MainFormController controller = new MainFormController();
        controller.inventory = this.inventory;
        stage.setScene(scene);
        stage.show();
    }

}
