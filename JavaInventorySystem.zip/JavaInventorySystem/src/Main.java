import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * @author Andrew Walsh
 * FUTURE ENHANCEMENT: In the future, I would add a database connection to this application to allow data to persist between user sessions.
 * JAVADOCS CAN BE FOUND IN THE javadocs FOLDER IN THE ROOT DIRECTORY OF THE PROJECT
 */
public class Main extends Application {

    /**
     * @param primaryStage the primary JavaFX stage for the application
     * @throws Exception
     * function to start the JavaFX application
     */
    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent parent = FXMLLoader.load(getClass().getResource("FXML/main.fxml"));
        Scene scene = new Scene(parent);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Inventory Management System");
        primaryStage.show();
    }


    /**
     * @param args arguments passed to the main method
     * function to launch the program
     */
    public static void main(String[] args) {
        launch(args);
    }
}
